/**
 * Exception Class which handles absent food problems.
 */
public class NotEnoughFood extends Exception{
    public NotEnoughFood(String message) {super(message);}
}
