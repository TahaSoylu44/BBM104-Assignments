/**
 * Exception Class for non-existing animals.
 */
public class AnimalNotFound extends Exception {
    public AnimalNotFound(String message) {
        super(message);
    }
}
